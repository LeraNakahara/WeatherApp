const form = document.querySelector("#form");
const input = document.querySelector('.search-input');
// КЛЮЧ ОТ OPENWEATHER
const API_KEY = '589ec1af9d069481fa79268b0052bfb2';

form.onsubmit = submitHandler;

 async function submitHandler(cancel){

    cancel.preventDefault();

// создаем поле ввода
    if (input.value === ""){
        console.log ("Введите название города");
        return;
    }

    const cityInfo = await getCity(input.value);
    input.value ='';
   const weatherInfo = await getWeather(cityInfo[0]['lat'],cityInfo[0]['lon']);
   console.log(weatherInfo);
 // создаем ассоциативный массив
    const weatherData = {
        name: weatherInfo.name,
        temp: weatherInfo.main.temp,
        press: weatherInfo.main.pressure,
        wind: weatherInfo.wind.speed,
        humidity: weatherInfo.main.humidity,
        //snow: weatherInfo.snow,
        //sunset: weatherInfo.sys.sunset,
        //sunrise: weatherInfo.sys.sunrise,
        main:weatherInfo.weather[0]['main']
    };

    // функция вывода погоды
    renderWeatherData(weatherData);
    //console.log(weatherInfo.main.name);

 }
    
    

// получаем локации
 async function getCity(name){
    const cityURL = `http://api.openweathermap.org/geo/1.0/direct?q=${name}&limit=10&appid=${API_KEY}`;
    const response = await fetch(cityURL);
    const data =  await response.json();
    console.log(data);
    return data;

}
// получаем данные о погоде
async function getWeather(lat, lon){
    const weatherURL = `https://api.openweathermap.org/data/2.5/weather?units=metric&lat=${lat}&lon=${lon}&appid=${API_KEY}`;
    const response =  await fetch(weatherURL);
    const data =  await response.json();
    return data;


}

 function renderWeatherData(data){
    const temp = document.querySelector('.temperature');
    const city = document.querySelector('.weather_city');
    const humidity = document.querySelector('#humidity');
    const pressure = document.querySelector('#pressure');
    const wind = document.querySelector('#wind');
    //const sunset = document.querySelector('#sunset');
    //const sunrise = document.querySelector('#sunrise');
    //const snow = document.querySelector('#precipitation');
    const img = document.querySelector('.weather_img');
    const colory = document.querySelector('.weather_container');

    //const sunsetTime = new Date(sunset * 1000);
    //const sunriseTime = new Date(sunrise * 1000);

        
    //const sunriseTake = sunriseTime.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
    //const sunsetTake = sunsetTime.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });

    temp.innerHTML = Math.round(data.temp) + " " + '&deg';
    city.innerHTML = data.name;
    humidity.innerHTML = data.humidity + " " + '%';
    pressure.innerHTML = Math.round(data.press) + " " +"мм рт.ст";
    wind.innerHTML = Math.round(data.wind) + " " + "м/с";
    //snow.innerHTML = data.snow + " " + "мм";
    //sunset.innerHTML = data.sunset;
    //sunrise.innerHTML = data.sunrise;

// картинки и цвет
    const fileNames = {
        'Clouds': 'cloud',
        'Clear': 'sun',
        'Rain':'rain',
        'Snow':'snow'
    }

    if(fileNames[data.main]){

    img.src = `${fileNames[data.main]}.svg`;

    }

    switch(data.main){
        case 'Clouds':
            colory.style.background = "linear-gradient(180deg, #141416 0%, #968E9F 100%)";
            break;
        case 'Clear':
            colory.style.background = "linear-gradient(180deg, #006ACC 0%, #64B5FF 100%)";
            break;
        case 'Rain':
            colory.style.background = "linear-gradient(180deg, #403E47 0%, #5E62C2 100%)";
            break;
        case 'Snow':
            colory.style.background = "linear-gradient(180deg, #195170 0%, #477087 0.01%, #1D24CD 100%)";
            break;
        default:
            break;


    }

}


 

